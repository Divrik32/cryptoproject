import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchCoins = createAsyncThunk('coins/fetchCoins', async () => {
  const response = await axios.get('https://api.coincap.io/v2/assets');
  return response.data.data;
});

const coinSlice = createSlice({
  name: 'coins',
  initialState: { list: [], status: 'idle' },
  reducers: {
    resetCoins: (state) => {
      state.list = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCoins.fulfilled, (state, action) => {
        state.list = action.payload;
        state.status = 'succeeded';
      });
  },
});

export const { resetCoins } = coinSlice.actions;
export default coinSlice.reducer;