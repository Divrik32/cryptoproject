import { configureStore } from '@reduxjs/toolkit';
import coinReducer from './coinSlice';
import cartReducer from './cartSlice';

const store = configureStore({
  reducer: {
    coins: coinReducer,
    cart: cartReducer,
  },
});

export default store;