import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  removeFromCart,
  incrementQuantity,
  decrementQuantity,
} from "../redux/cartSlice";
import {
  Paper,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Box,
  ButtonGroup,
  Button,
  Divider,
  Card,
  CardContent,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";

const Cart = () => {
  const cartItems = useSelector((state) => state.cart);
  const dispatch = useDispatch();
  const [isEditing, setIsEditing] = useState(false);
  const totalQuantity = cartItems.reduce(
    (total, item) => total + (item.quantity || 0),
    0
  );
  const totalAmount = cartItems.reduce(
    (total, item) => total + parseFloat(item.priceUsd) * item.quantity,
    0
  );

  return (
    <Box
      sx={{
        minHeight: "100vh",
        padding: 3,
        backgroundColor: "#f5f5f5",
      }}
    >
      <Card
        elevation={3}
        sx={{
          maxWidth: 800,
          margin: "0 auto",
          backgroundColor: "white",
          borderRadius: 2,
        }}
      >
        <CardContent>
          <Box sx={{ display: "flex", alignItems: "center", mb: 3 }}>
            <ShoppingCartIcon
              sx={{ fontSize: 32, mr: 2, color: "primary.main" }}
            />
            <Typography variant="h4" color="primary.main">
              Your Cart
            </Typography>
          </Box>

          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
            <Typography variant="h6">Total Items: {totalQuantity}</Typography>
            <Typography variant="h6" color="primary.main">
              Total Amount: ${totalAmount.toFixed(2)}
            </Typography>
          </Box>

          <Divider sx={{ mb: 2 }} />

          {cartItems.length === 0 ? (
            <Typography
              variant="h6"
              align="center"
              sx={{ py: 4, color: "text.secondary" }}
            >
              Your cart is empty
            </Typography>
          ) : (
            <List>
              {cartItems.map((item) => (
                <React.Fragment key={item.id}>
                  <ListItem
                    sx={{
                      py: 2,
                      backgroundColor: "#f8f9fa",
                      borderRadius: 1,
                      mb: 1,
                    }}
                  >
                    <Box sx={{ width: "100%" }}>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          mb: 1,
                        }}
                      >
                        <Typography variant="h6" color="primary.main">
                          {item.name}
                        </Typography>
                        <Typography variant="body1">
                          $
                          {(parseFloat(item.priceUsd) * item.quantity).toFixed(
                            2
                          )}
                        </Typography>
                      </Box>

                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        {isEditing ? (
                          <ButtonGroup
                            variant="contained"
                            size="small"
                            sx={{ backgroundColor: "white" }}
                          >
                            <Button
                              onClick={() => dispatch(decrementQuantity(item))}
                              disabled={item.quantity <= 1}
                            >
                              <RemoveIcon fontSize="small" />
                            </Button>
                            <Button
                              disabled
                              sx={{ px: 2, color: "text.primary" }}
                            >
                              {item.quantity}
                            </Button>
                            <Button
                              onClick={() => dispatch(incrementQuantity(item))}
                            >
                              <AddIcon fontSize="small" />
                            </Button>
                          </ButtonGroup>
                        ) : (
                          <Button
                            disabled
                            sx={{ px: 2, color: "text.primary" }}
                          >
                            {item.quantity}
                          </Button>
                        )}

                        {isEditing && (
                          <IconButton
                            onClick={() => dispatch(removeFromCart(item))}
                            sx={{
                              color: "error.main",
                              "&:hover": { backgroundColor: "error.light" },
                            }}
                          >
                            <DeleteIcon />
                          </IconButton>
                        )}
                      </Box>
                    </Box>
                  </ListItem>
                </React.Fragment>
              ))}
            </List>
          )}
          <Button
            variant="outlined"
            size="medium"
            onClick={() => setIsEditing(!isEditing)}
          >
            {isEditing ? "Save Cart" : "Edit Cart"}
          </Button>
          {cartItems.length > 0 && (
            <Box sx={{ mt: 3, display: "flex", justifyContent: "flex-end" }}>
              <Button variant="contained" size="large" sx={{ minWidth: 200 }}>
                Checkout
              </Button>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default Cart;
