import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useQuery } from "@tanstack/react-query";
import CoinDetailsModal from "./CoinDetailsModal";
import { addToCart, resetCart } from "../redux/cartSlice";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Button,
  Typography,
  CircularProgress,
  Paper,
  Box,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import { useNavigate } from "react-router-dom";

const fetchCoins = async () => {
  const response = await axios.get("https://api.coincap.io/v2/assets");
  return response.data.data;
};

const CoinTable = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCoin, setSelectedCoin] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const {
    data: coins = [],
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["coins"],
    queryFn: fetchCoins,
  });

  const handleRefresh = () => {
    dispatch(resetCart());
    refetch();
  };

  const filteredCoins = coins.filter((coin) =>
    coin.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddToCart = (coin) => {
    dispatch(addToCart(coin));
    navigate("/cart");
  };

  if (isLoading) return <CircularProgress />;

  return (
    <Paper sx={{ padding: 2 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 2,
        }}
      >
        <Typography variant="h4" gutterBottom>
          Cryptocurrency List
        </Typography>
        <Button
          variant="contained"
          startIcon={<RefreshIcon />}
          onClick={handleRefresh}
          sx={{ height: "fit-content" }}
        >
          Refresh
        </Button>
      </Box>
      <TextField
        variant="outlined"
        label="Search"
        fullWidth
        margin="normal"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Price</TableCell>
              <TableCell>Market Cap</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredCoins.map((coin) => (
              <TableRow key={coin.id}>
                <TableCell>{coin.name}</TableCell>
                <TableCell>${coin.priceUsd}</TableCell>
                <TableCell>${coin.marketCapUsd}</TableCell>
                <TableCell>
                  <Button
                    variant="outlined"
                    onClick={() => {
                      setSelectedCoin(coin);
                      setModalOpen(true);
                    }}
                    sx={{ marginRight: 1 }}
                  >
                    View Details
                  </Button>
                  <Button
                    variant="contained"
                    onClick={() => handleAddToCart(coin)}
                  >
                    Add to Cart
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      {modalOpen && (
        <CoinDetailsModal
          coin={selectedCoin}
          onClose={() => setModalOpen(false)}
        />
      )}
    </Paper>
  );
};

export default CoinTable;
