import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addToCart } from '../redux/cartSlice';
import { Button, Typography, Modal, Box, TextField } from '@mui/material';

const CoinDetailsModal = ({ coin, onClose }) => {
  const dispatch = useDispatch();
  const [editedCoin, setEditedCoin] = useState({
    name: coin?.name || '',
    priceUsd: coin?.priceUsd || '',
    marketCapUsd: coin?.marketCapUsd || ''
  });

  const handleAddToCart = () => {
    dispatch(addToCart(editedCoin));
    onClose();
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedCoin(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (!coin) return null;

  return (
    <Modal open onClose={onClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '100%', 
          maxWidth: 600, 
          bgcolor: 'background.paper',
          boxShadow: 24,
          borderRadius: 2,
          p: 4,
          outline: 'none',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2
        }}
      >
        <TextField
          fullWidth
          label="Name"
          name="name"
          value={editedCoin.name}
          onChange={handleInputChange}
        />
        <TextField
          fullWidth
          label="Price USD"
          name="priceUsd"
          value={editedCoin.priceUsd}
          onChange={handleInputChange}
          type="number"
        />
        <TextField
          fullWidth
          label="Market Cap USD"
          name="marketCapUsd"
          value={editedCoin.marketCapUsd}
          onChange={handleInputChange}
          type="number"
        />
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
          <Button variant="contained" onClick={handleAddToCart} sx={{ marginRight: 1 }}>
            Add to Cart
          </Button>
          <Button variant="outlined" onClick={onClose}>
            Close
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default CoinDetailsModal;