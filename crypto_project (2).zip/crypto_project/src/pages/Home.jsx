import React from 'react';
import CoinTable from '../components/CoinTable';

const Home = () => {
  return (
    <div>
      <CoinTable />
    </div>
  );
};

export default Home;
