import React from 'react';
import Cart from '../components/Cart';

const CartPage = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default CartPage;
